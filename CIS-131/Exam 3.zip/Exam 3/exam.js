
$(document).ready(() => {
    $.ajax({
        url:'https://api.themoviedb.org/3/tv/popular?api_key=065ba404968cd2bb5916e5ae06e33fcb&language=en-US&page=1',
        success: (result) =>{
            var app = new Vue({
                el:'#app',
                data:{
                    tvShows:[result.results[0], result.results[1], result.results[2], result.results[3], result.results[4], result.results[5], result.results[6], result.results[7], result.results[8], result.results[9], result.results[10], result.results[11], result.results[12], result.results[13], result.results[14], result.results[15], result.results[16], result.results[17], result.results[18], result.results[19],]
                }
            })
        }
    })
})



